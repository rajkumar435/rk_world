﻿using System.ComponentModel.DataAnnotations;

namespace DeviceApi.Models
{
    public class DeviceCreateDto
    {
        [Required]
        public string DeviceId { get; set; }

        [Required]
        public string TestCode { get; set; }

        [Required]
        public int OrgId { get; set; }

        public bool IsReflex { get; set; }
    }
}

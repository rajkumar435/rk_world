﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using DeviceApi.Models;

namespace DeviceApi.Models
{
    public class DeviceDbContext : DbContext
    {
        public DeviceDbContext(DbContextOptions<DeviceDbContext> options) : base(options)
        {
        }

        public DbSet<Device> Devices { get; set; }
    }
}

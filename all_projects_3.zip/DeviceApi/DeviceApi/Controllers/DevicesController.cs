﻿using DeviceApi.Models;
using Microsoft.AspNetCore.Mvc;

namespace DeviceApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DevicesController : ControllerBase
    {
        private readonly DeviceDbContext _context;

        public DevicesController(DeviceDbContext context)
        {
            _context = context;
        }

        // POST api/devices
        [HttpPost]
        [Consumes("application/x-www-form-urlencoded")] // Use form fields
        public IActionResult PostDevice([FromForm] DeviceCreateDto dto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var device = new Device
            {
                DeviceId = dto.DeviceId,
                TestCode = dto.TestCode,
                OrgId = dto.OrgId,
                IsReflex = dto.IsReflex
            };

            _context.Devices.Add(device);
            _context.SaveChanges();

            return CreatedAtAction(nameof(GetDevice), new { id = device.Id }, device);
        }

        // GET api/devices/{id}
        [HttpGet("{id}")]
        public IActionResult GetDevice(int id)
        {
            var device = _context.Devices.Find(id);
            if (device == null)
            {
                return NotFound();
            }
            return Ok(device);
        }
    }
}

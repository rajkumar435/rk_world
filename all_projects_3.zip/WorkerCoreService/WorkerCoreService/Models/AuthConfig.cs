﻿namespace WorkerCoreService.Models
{
    public class AuthConfig
    {
        public int Id { get; set; }
        public string AuthUrl { get; set; }
        public string GrantType { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string OrgId { get; set; }
        public bool IsActive { get; set; }
        public ICollection<ApiConfig> ApiConfigs { get; set; }

    }
}

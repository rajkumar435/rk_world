﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace WorkerCoreService.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<AuthConfig> AuthConfigs { get; set; }
        public DbSet<ApiConfig> ApiConfigs { get; set; }
    }
}

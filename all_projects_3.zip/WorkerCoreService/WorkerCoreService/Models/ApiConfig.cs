﻿namespace WorkerCoreService.Models
{
    public class ApiConfig
    {

        public int Id { get; set; }
        public string ServiceName { get; set; }
        public string ApiUrl { get; set; }
        public string HttpMethod { get; set; }
        public int AuthConfigId { get; set; }
        public AuthConfig AuthConfig { get; set; }
        public bool IsActive { get; set; }
        public string HeadersJson { get; set; }
        public string BodyTemplate { get; set; }
        public int CallIntervalSec { get; set; }
        public string Description { get; set; }
    }
}

﻿using System.Net.Http.Headers;
using System.Text;
using WorkerCoreService.Models;

using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
//using Newtonsoft.Json;

namespace WorkerCoreService
{
    //public class Worker
    //{
    //}





    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private readonly IServiceScopeFactory _scopeFactory;
        private readonly IHttpClientFactory _httpClientFactory;

        private string _authToken;
        private DateTime _tokenExpiryTime;

        private AuthConfig _authConfig;
        private ApiConfig _apiConfig;

        private readonly string _serviceName = "GetPDF"; // This can be made dynamic or read from config if needed

        public Worker(
            ILogger<Worker> logger,
            IServiceScopeFactory scopeFactory,
            IHttpClientFactory httpClientFactory)
        {
            _logger = logger;
            _scopeFactory = scopeFactory;
            _httpClientFactory = httpClientFactory;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            using var scope = _scopeFactory.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();

            _apiConfig = await db.ApiConfigs
                .Include(a => a.AuthConfig)
                .FirstOrDefaultAsync(a => a.ServiceName == _serviceName && a.IsActive, cancellationToken: stoppingToken);

            if (_apiConfig == null)
            {
                _logger.LogError("No active API config found for service: {ServiceName}", _serviceName);
                return;
            }

            _authConfig = _apiConfig.AuthConfig;

            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    // Refresh token only if expired
                    if (string.IsNullOrEmpty(_authToken) || DateTime.UtcNow >= _tokenExpiryTime)
                    {
                        await AuthenticateAsync(stoppingToken);
                    }

                    if (!string.IsNullOrEmpty(_authToken))
                    {
                        await CallServiceApiAsync(stoppingToken);
                    }
                    else
                    {
                        _logger.LogWarning("Token acquisition failed. Skipping API call.");
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Worker execution error for service: {ServiceName}", _serviceName);
                }

                int delaySeconds = _apiConfig.CallIntervalSec > 0 ? _apiConfig.CallIntervalSec : 60;
                await Task.Delay(TimeSpan.FromSeconds(delaySeconds), stoppingToken);
            }
        }

        private async Task AuthenticateAsync(CancellationToken cancellationToken)
        {
            var client = _httpClientFactory.CreateClient();

            var formData = new Dictionary<string, string>
        {
            {"grant_type", _authConfig.GrantType},
            {"username", _authConfig.Username},
            {"password", _authConfig.Password},
            {"client_id", _authConfig.ClientId},
            {"client_secret", _authConfig.ClientSecret}
        };

            try
            {
                var response = await client.PostAsync(_authConfig.AuthUrl, new FormUrlEncodedContent(formData), cancellationToken);

                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync(cancellationToken);
                    var tokenResponse = JsonConvert.DeserializeObject<TokenResponse>(content);
                    _authToken = tokenResponse.Access_Token;

                    // Optional: if token expiry is returned, use it. Here, we assume 1 hour validity.
                    _tokenExpiryTime = DateTime.UtcNow.AddMinutes(55);

                    _logger.LogInformation("Auth successful for {ServiceName}. Token acquired.", _serviceName);
                }
                else
                {
                    _authToken = null;
                    _logger.LogWarning("Auth failed for {ServiceName}. Status: {StatusCode}", _serviceName, response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _authToken = null;
                _logger.LogError(ex, "Exception during token generation for {ServiceName}", _serviceName);
            }
        }

        private async Task CallServiceApiAsync(CancellationToken cancellationToken)
        {
            var client = _httpClientFactory.CreateClient();
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _authToken);

            // Optional headers from JSON
            if (!string.IsNullOrEmpty(_apiConfig.HeadersJson))
            {
                try
                {
                    var headers = JsonConvert.DeserializeObject<Dictionary<string, string>>(_apiConfig.HeadersJson);
                    foreach (var header in headers)
                    {
                        client.DefaultRequestHeaders.TryAddWithoutValidation(header.Key, header.Value);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error parsing headers for {ServiceName}", _serviceName);
                }
            }

            try
            {
                HttpResponseMessage response;

                // Prepare request body if needed
                HttpContent? bodyContent = null;
                if (!string.IsNullOrWhiteSpace(_apiConfig.BodyTemplate))
                {
                    bodyContent = new StringContent(_apiConfig.BodyTemplate, Encoding.UTF8, "application/json");
                }

                // Send request based on method
                response = _apiConfig.HttpMethod.ToUpper() switch
                {
                    "GET" => await client.GetAsync(_apiConfig.ApiUrl, cancellationToken),
                    "POST" => await client.PostAsync(_apiConfig.ApiUrl, bodyContent, cancellationToken),
                    "PUT" => await client.PutAsync(_apiConfig.ApiUrl, bodyContent, cancellationToken),
                    "DELETE" => await client.DeleteAsync(_apiConfig.ApiUrl, cancellationToken),
                    _ => throw new NotSupportedException($"HTTP method '{_apiConfig.HttpMethod}' is not supported.")
                };

                if (response.IsSuccessStatusCode)
                {
                    var responseData = await response.Content.ReadAsStringAsync(cancellationToken);

                    _logger.LogInformation("API call succeeded for {ServiceName}.", _serviceName);
                    _logger.LogDebug("API Response: {Data}", responseData);

                    // Optionally process data here
                    // var result = JsonConvert.DeserializeObject<YourResponseModel>(responseData);
                }
                else
                {
                    _logger.LogWarning("API call failed for {ServiceName}. Status: {StatusCode}", _serviceName, response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Exception during API call for {ServiceName}", _serviceName);
            }
        }

        private class TokenResponse
        {
            [JsonProperty("access_token")]
            public string Access_Token { get; set; }

            // If your API returns expiry, add this:
            // [JsonProperty("expires_in")]
            // public int ExpiresInSeconds { get; set; }
        }
    }

}
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.EntityFrameworkCore;
using WorkerCoreService; // Your namespace for Worker
using WorkerCoreService.Models; // Your namespace for AppDbContext
using Microsoft.Extensions.Logging;

public class Program
{
    public static void Main(string[] args)
    {
        CreateHostBuilder(args).Build().Run();
    }

    public static IHostBuilder CreateHostBuilder(string[] args) =>
        Host.CreateDefaultBuilder(args)

            // Setup the MVC Web App
            .ConfigureWebHostDefaults(webBuilder =>
            {
                webBuilder.UseStartup<Worker>();
            })

            // Register services like DbContext, Worker, HttpClient
            .ConfigureServices((context, services) =>
            {
                // Register EF DbContext
                services.AddDbContext<AppDbContext>(options =>
                    options.UseSqlServer(
                        context.Configuration.GetConnectionString("DefaultConnection")));

                // Register HTTP client
                services.AddHttpClient();

                // Register background worker service
                services.AddHostedService<Worker>();
            });
}

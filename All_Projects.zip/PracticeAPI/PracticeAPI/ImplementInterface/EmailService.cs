﻿using PracticeAPI.Interface;
using System;

namespace PracticeAPI.ImplementInterface
{
    public class EmailService : IEmail
    {
        private readonly string _id;

        public EmailService()
        {
            _id = Guid.NewGuid().ToString();
        }

        public string SendEmail()
        {
            return _id;
        }
    }
}

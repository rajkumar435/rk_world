﻿namespace PracticeAPI.Interface
{
    public interface IEmail
    {
        string SendEmail();
    }
}

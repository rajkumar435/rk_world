﻿using System;
using Microsoft.AspNetCore;
using System.Data;
using Microsoft.EntityFrameworkCore;
using PracticeAPI.Models;



namespace PracticeAPI.Data
{
    public class AppDbContext : DbContext
    {
      public  AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        { 
        
        }

        public DbSet<Address>addresses { get; set; }
    }
}

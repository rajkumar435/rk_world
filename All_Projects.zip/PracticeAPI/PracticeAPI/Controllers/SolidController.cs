﻿using Microsoft.AspNetCore.Mvc;
using PracticeAPI.Interface;

namespace PracticeAPI.Controllers
{



    [ApiController]
    [Route("[controller]")]
    //public class SolidController : Controller
    //{
    //    private readonly IEmail _email;
    //    public SolidController(IEmail email) 
    //    { 

    //        _email= email;
    //    }
    //    [HttpGet("notification")]
    //    public string Notification()
    //    {
    //      string result =   _email.SendEmail();
    //        return result;
    //    }
    //    //public IActionResult Index()
    //    //{
    //    //    return View();
    //    //}
    //}

    public class SolidController : ControllerBase
    {
        private readonly IEmail _email1;
        private readonly IEmail _email2;

        public SolidController(IEmail email1, IEmail email2)
        {
            _email1 = email1;
            _email2 = email2;
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Ok(new
            {
                Email1 = _email1.SendEmail(),
                Email2 = _email2.SendEmail()
            });
        }
    }

}

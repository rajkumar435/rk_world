﻿using Microsoft.AspNetCore.Mvc;
using PracticeAPI.Models;
using PracticeAPI.Interface;
using PracticeAPI.Data;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace PracticeAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserAddressController : Controller
    {
     //   private readonly Address _address;

        private readonly AppDbContext _appDbContext;

        public UserAddressController( AppDbContext appDbContext)
        {
          //  _address = address;
            _appDbContext = appDbContext;
        }

        [HttpGet]
        public async Task<ActionResult<List<Address>>> GetAddress()
        {
            var result = await _appDbContext.addresses.ToListAsync();


            return Ok(result);
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<List<Address>>> GetAddressId( int id)
        {
            var result = await _appDbContext.addresses
                .FirstOrDefaultAsync(e => e.Id ==id);

            if (result == null)
                return BadRequest();

            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult<List<Address>>> AddAddress(Address address)
        {
          await _appDbContext.addresses.AddAsync(address);
            await _appDbContext.SaveChangesAsync();

            return CreatedAtAction(nameof(GetAddressId), new {id =address.Id},address);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<List<Address>>> UpdateAddress(int id,Address updateaddress)
        {

           var address =  await _appDbContext.addresses.FindAsync(id);
          
            if(address == null) 
                return BadRequest();
            
            address.Street = updateaddress.Street;
            
            
            await _appDbContext.SaveChangesAsync();

            return Ok();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<List<Address>>> DeleteAddress(int id)
        {

           var address = await _appDbContext.addresses.FindAsync(id);
            if (address == null)    
                return BadRequest();
            _appDbContext.addresses.Remove(address);
            await _appDbContext.SaveChangesAsync();

            return Ok();
        }


    }
}

﻿using Microsoft.AspNetCore.Mvc;

namespace PracticeAPI.Controllers
{
    public class User
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
    }

    [ApiController]
    [Route("[controller]")]
    public class HomeController : Controller
    {

        private static List<User> users = new List<User>
    {
        new User { ID = 1, Name = "rajkumar", Email = "rajkumar@gmail.com" },
        new User { ID = 2, Name = "unduru", Email = "unduru@gmail.com" },
        new User { ID = 3, Name = "prince", Email = "prince@gmail.com" }
    };


        [HttpGet]
        public  ActionResult<List<User>> Index()
        {
          


            return Ok(users);
        }


        [HttpPost]
        public ActionResult Add()
        {
            User user = new User
            //  List<User> user1 = null;
            //  user = new User();
            //   user1 = new List<User>();
            {
                ID = 4,
                Name = "URK",
                Email = "urk@gmail.com"

            };
                            users.Add(user);
            return Ok();
        }

    }
}

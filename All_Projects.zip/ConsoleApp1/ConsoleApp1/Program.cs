﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    // Online C# Editor for free
    // Write, Edit and Run your C# code using C# Online Compiler

    //  using System;

    public class Program
    {
        public static void Main(string[] args)
        {
            //  Input: nums = [1,3,-1,-3,5,3,6,7], k = 3  

            //Output: [3,3,5,5,6,7]

            int[] arr = { 1, 3, -1, -3, 5, 3, 6, 7 };
            int k = 3;

            for (int i = 0; i < arr.Length; i++)
            {
                int c = 0;

                int max = arr[i];
                while (c <= k)
                {

                    if (max < arr[i])
                    {
                        max = arr[i];
                    }
                }
                Console.Write(max);

            }

        }
    }
}

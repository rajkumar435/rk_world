﻿using System;

public class Prime
{

    public static void Main(String[] args)
    {
        int n = 20;
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine("Hello rk " + i + "is" +isPrime(i));
        }
    }

    static bool isPrime(int n)
    {
        if (n <= 1)
        {  return false; }
        int c = 2;
        while (c * c <= n)
        {
            if (n % c == 0)
            {
                return false;
            }
            c++;
        }
        return true;
    }
}


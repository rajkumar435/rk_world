﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolidPrinciples
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region without OCP
            // ProductCategory category = new ProductCategory();
            //double output = category.CalculateDiscount(10, CategoryType.premium);
            // Console.WriteLine(output);
            #endregion

            #region with OCP
            //var premium = new PremiumCalculator();
            //var category = new  Discount(premium);
            //double d = category.discountCalculator(10);

            //var normal = new PremiumCalculator();
            // category = new Discount(normal);
            // d = category.discountCalculator(10);

            //var pro = new PremiumCalculator();
            // category = new Discount(pro);
            // d = category.discountCalculator(10);

            //Console.WriteLine(d);
            #endregion

            #region without LSP

           //// Father father = new Father();
           // Son son = new Son();
           // son.Prof();
           // Father father = new Son();
           // father.Prof();
            #endregion

            #region with LSP

            Father father = new Father();
            Parent p = new Father();
            p.Prof();
            p = new Son();
            p.Prof();
            #endregion
        }

    }
}

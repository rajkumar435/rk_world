﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolidPrinciples
{
    #region without OCP
    //public class OCP
    //{

    //}

    ////public class Product
    ////{
    ////    public int ID { get; set; }
    ////    public int Name { get; set; }
    ////    public double Price { get; set; }

    ////}
    //public enum CategoryType
    //{
    //    premium,
    //    normal,
    //    pro

    //}

    //public class ProductCategory
    //{
    //    public double CalculateDiscount(double Price, CategoryType categoryType)
    //    {
    //        switch (categoryType)
    //        {
    //            case CategoryType.premium:
    //                return Price * 10;
    //                case CategoryType.normal:
    //                return Price * 20;
    //                case CategoryType.pro:
    //                return Price * 30;
    //                default:
    //                return Price;
    //        }

    //    }

    //}
    #endregion


    #region with OCP

    public interface ICategoryStratagy
    {
         double CalculateDiscount(double Price);
    }

    public class PremiumCalculator :ICategoryStratagy
    {
        public double CalculateDiscount(double Price)
        {
            return Price * 10;
        }

    }

    public class NormalCalculator : ICategoryStratagy
    {
        public double CalculateDiscount(double Price)
        {
            return Price * 5;
        }

    }

    public class ProCalculator : ICategoryStratagy
    {
        public double CalculateDiscount(double Price)
        {
            return Price * 2;
        }

    }

    public class Discount
    {
        ICategoryStratagy _categoryStratagy;
        public Discount(ICategoryStratagy categoryStratagy)
        {
            _categoryStratagy = categoryStratagy;
        }

        public double discountCalculator(double Price)
        {
            return _categoryStratagy.CalculateDiscount(Price);
        }
    }

    #endregion
}

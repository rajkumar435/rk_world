﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolidPrinciples
{
    #region without SRP
    public class SRP
    {

            SqlConnection con = new SqlConnection("Data Source =RAJKUMAR-LAP;Initial Catalog=unduru;username=sa;password=A$$une;");
        

        public void insert()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand();
        }

    }
    #endregion
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime;
using System.Text;
using System.Threading.Tasks;

namespace SolidPrinciples
{
    internal class LSP
    {
    }

    #region without LSP

    //public abstract class Father
    //{
    //    public virtual void Prof()
    //    {
    //        Console.WriteLine("Former");
    //    }
    //}
    //public class Son : Father
    //{
    //    public override void Prof()
    //    {
    //        Console.WriteLine("engineer");
    //    }
    //}


    #endregion

    #region with LSP

    public abstract class Parent
    {
        public abstract void Prof();

    }
    public class Father : Parent
    {
        public override void Prof()
        {
            Console.WriteLine("Former");
        }
    }
    public class Son : Parent
    {
        public override void Prof()
        {
            Console.WriteLine("engineer");
        }
    }


    #endregion


}

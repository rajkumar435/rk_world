﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
 
namespace Evoke
{
    public partial class Service1 : ServiceBase
    {
        private string _connectionString = "Server=RAJKUMAR-LAP;Database=unduru;User Id=sa;Password=A$$une;";
        // Update with your connection string
      //  private string _connectionString = ConfigurationManager.ConnectionStrings["MyDatabaseConnection"].ConnectionString;

        public Service1()
        {
            InitializeComponent();
            FetchAndProcessData();
        }
        private System.Timers.Timer timer;

        protected override void OnStart(string[] args)
        {
            timer = new System.Timers.Timer();
            timer.Interval = 60000; // 1 minute
            timer.Elapsed += Timer_Elapsed;
            timer.Start();
        }

        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            // Fetch data from the database
            //FetchAndProcessData();
        }

        // Fetch data from the database and process it
        private void FetchAndProcessData()
        {
            string query = "SELECT Id, Name, Value FROM MyTable WHERE Processed = 0"; // Query to fetch unprocessed records

            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    // Execute the query and process results
                    using (var command = new SqlCommand(query, connection))
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                int id = reader.GetInt32(0);  // Read Id
                                string name = reader.GetString(1);  // Read Name
                                int value = reader.GetInt32(2);  // Read Value

                                // Perform your business logic here, e.g., update Value
                                int processedValue = ProcessData(value);

                                // Now, update the processed record in the database
                                UpdateDatabase(id, processedValue);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Log any errors to a file or event log
              //  File.AppendAllText(@"C:\Logs\MyServiceErrorLog.txt", $"Error fetching and processing data: {ex.Message}\n");
            }
        }

        // Example of business logic: modify or process the data
        private int ProcessData(int value)
        {
            // Example: Just increment the value for processing
            return value + 1;
        }

        // Update the database with processed data
        private void UpdateDatabase(int id, int processedValue)
        {
            string updateQuery = "UPDATE MyTable SET Value = @processedValue, Processed = 1 WHERE Id = @id";

            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    // Execute the update command
                    using (var command = new SqlCommand(updateQuery, connection))
                    {
                        command.Parameters.AddWithValue("@processedValue", processedValue);
                        command.Parameters.AddWithValue("@id", id);

                        int rowsAffected = command.ExecuteNonQuery();

                        // Log success if needed
                      //  File.AppendAllText(@"C:\Logs\MyServiceLog.txt", $"Updated record with Id: {id}, processed value: {processedValue}\n");
                    }
                }
            }
            catch (Exception ex)
            {
                // Log any errors that occur during the update
               // File.AppendAllText(@"C:\Logs\MyServiceErrorLog.txt", $"Error updating record Id {id}: {ex.Message}\n");
            }
        }

        // This will stop the service and clean up resources
        protected override void OnStop()
        {
            timer.Stop();
            timer.Dispose();
        }
    }
}


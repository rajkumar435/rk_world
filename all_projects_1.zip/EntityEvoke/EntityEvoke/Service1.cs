﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace EntityEvoke
{
    public partial class Service1 : ServiceBase
    {
        private Timer _timer;
        private unduruEntities _context; // DbContext for Entity Framework

        public Service1()
        {
            InitializeComponent();

            _context = new unduruEntities(); // Initialize EF DbContext
            ProcessData();
        }

        // This will be triggered when the service starts
        protected override void OnStart(string[] args)
        {
            _timer = new Timer(300000); // Run every 5 minutes (300000 ms)
            _timer.Elapsed += Timer_Elapsed;
            _timer.Start();
        }

        // Timer event that processes data every 5 minutes
        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            ProcessData();
        }

        // Fetch and process unprocessed records from the database
        private void ProcessData()
        {
            try
            {
                // Fetch unprocessed records from the database
                var records = _context.MyTables.Where(t => (bool)!t.Processed).ToList();

                foreach (var record in records)
                {
                    // Example processing: increment the Value by 1
                    record.Value += 1;

                    // Mark the record as processed
                    record.Processed = true;

                    // Log the processed record
                   // File.AppendAllText(@"C:\Logs\MyServiceLog.txt",
                      //  $"Processed record {record.Name}, New Value: {record.Value} at {DateTime.Now}\n");
                }

                // Save the changes to the database (commits the updates)
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                // Log any errors
            //    File.AppendAllText(@"C:\Logs\MyServiceErrorLog.txt", $"Error processing records: {ex.Message}\n");
            }
        }

        // This will stop the service and clean up resources
        protected override void OnStop()
        {
            _timer.Stop();
            _timer.Dispose();
            _context.Dispose();  // Dispose DbContext to free up resources
        }
    }
}


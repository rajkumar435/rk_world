﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LoginUpdateCoreAPI.Models
{

    [Table("Login")]
    public class Login
    {
        //  //   public long loginID { get; set; }
        //  [Key] // ✅ EF Core knows this is the PK
        ////  public long loginID { get; set; }
        //  public string LoginName { get; set; }
        //  public string? Password { get; set; }
        //  public string? IsLocked { get; set; }
        //  public string? HasUserChangedPassword { get; set; }
        //  public int? NoOfFailureAttempts { get; set; }
        //  public string? Status { get; set; }
        //  public DateTime? LoginPwdExpDate { get; set; }

        [Key]
        public string LoginName { get; set; }

        [MaxLength(255)]
        public string? Password { get; set; }

        [MaxLength(1)]
        public string? IsLocked { get; set; }

        [MaxLength(1)]
        public string? HasUserChangedPassword { get; set; }

        [MaxLength(1)]
        public string? Status { get; set; }

        public int? NoOfFailureAttempts { get; set; }
        public DateTime? LoginPwdExpDate { get; set; }


    }
}

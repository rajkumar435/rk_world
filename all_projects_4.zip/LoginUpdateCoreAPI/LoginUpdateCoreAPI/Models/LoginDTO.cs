﻿namespace LoginUpdateCoreAPI.Models
{
    public class LoginDTO
    {

        public string Password { get; set; }
        public string IsLocked { get; set; }
        public string HasUserChangedPassword { get; set; }
        public int NoOfFailureAttempts { get; set; }
        public string Status { get; set; }
        public DateTime LoginPwdExpDate { get; set; }
    }
}

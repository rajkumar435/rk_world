﻿using LoginUpdateCoreAPI.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace LoginUpdateCoreAPI.Models
{
    public class LoginDbContext : DbContext
    {
        public LoginDbContext(DbContextOptions<LoginDbContext> options) : base(options)
        {
        }

        public DbSet<Login>Logins{ get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Login>().ToTable("Login");
        }
    }

}

﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using LoginUpdateCoreAPI.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;


public class Startup
{
    public IConfiguration Configuration { get; }

    public Startup(IConfiguration configuration)
    {
        Configuration = configuration;
    }

    public void ConfigureServices(IServiceCollection services)
    {
        // Add controllers (API support)
        services.AddControllers();

        // Add Entity Framework and your DbContext
        services.AddDbContext<LoginDbContext>(options =>
            options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));



        // Add Swagger for API documentation
        services.AddSwaggerGen(c =>
        {
            c.SwaggerDoc("v1", new OpenApiInfo
            {
                Title = "Device API",
                Version = "v1"
            });
        });
    }

    public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
    {
        // Enable Swagger UI
        app.UseSwagger();
        app.UseSwaggerUI(c =>
        {
            c.SwaggerEndpoint("/swagger/v1/swagger.json", "Device API V1");
            c.RoutePrefix = string.Empty; // Swagger at http://localhost:<port>/
        });

        if (env.IsDevelopment())
        {
            app.UseDeveloperExceptionPage();
        }
        else
        {
            app.UseExceptionHandler("/Home/Error");
        }

        app.UseRouting();
        app.UseAuthorization();

        // Map routes
        app.UseEndpoints(endpoints =>
        {
            endpoints.MapControllers();
        });
    }
}

﻿using LoginUpdateCoreAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Threading.Tasks;

namespace LoginUpdateCoreAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LoginController : ControllerBase
    {
        private readonly LoginDbContext _context;

        public LoginController(LoginDbContext context)
        {
            _context = context;
        }

        [HttpPut("{LoginName}")]
        public async Task<IActionResult> UpdateItem(string LoginName, [FromForm] LoginDTO dto)
        {
            var item = await _context.Logins.FirstOrDefaultAsync(x => x.LoginName == LoginName);
            if (item == null)
            {
                return NotFound($"Login with LoginName '{LoginName}' not found.");
            }

            // Set default password
          //  item.Password = "9XJ/qqe45hc=";

            //// If IsLocked is "Y", change to "N"
            //item.IsLocked = dto.IsLocked == "Y" ? "N" : dto.IsLocked;

            //// You can apply similar rules to other fields
            //item.HasUserChangedPassword = string.IsNullOrEmpty(dto.HasUserChangedPassword) ? "Y" : dto.HasUserChangedPassword;

            //// Keep these as-is (or apply defaults as needed)
            //item.NoOfFailureAttempts = dto.NoOfFailureAttempts;
            //item.Status = dto.Status ?? "A"; // Default to "Active" if null
            //item.LoginPwdExpDate = dto.LoginPwdExpDate == default ? DateTime.Now.AddMonths(3) : dto.LoginPwdExpDate;

            // Default password (as per your original requirement)
            item.Password = "9XJ/qqe45hc=";

            // IsLocked: Convert "Y" to "N", else set as "Y"/"N" only
            item.IsLocked = dto.IsLocked == "Y" ? "N" : "Y"; // fallback

            // HasUserChangedPassword: default to "Y" if null/empty
            item.HasUserChangedPassword = string.IsNullOrWhiteSpace(dto.HasUserChangedPassword)
                ? "Y"
                : dto.HasUserChangedPassword.Length > 1 ? "Y" : dto.HasUserChangedPassword; // defensive

            // Status: default to "A"
            item.Status = string.IsNullOrWhiteSpace(dto.Status) ? "A" : dto.Status.Length > 10 ? "A" : dto.Status;

            // Failure attempts: allow direct value
            item.NoOfFailureAttempts = dto.NoOfFailureAttempts;

            // Password expiry date: default to 3 months from now
            item.LoginPwdExpDate = dto.LoginPwdExpDate == default
                ? DateTime.Now.AddMonths(3)
                : dto.LoginPwdExpDate;



            await _context.SaveChangesAsync();

            return NoContent(); // or Ok(item) if you want to return updated object
        }
    }
}

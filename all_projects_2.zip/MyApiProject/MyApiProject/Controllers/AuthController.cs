﻿using Microsoft.AspNetCore.Mvc;
using MyApiProject.Models;


namespace MyApiProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        [HttpPost("token")]
        public ActionResult Token([FromForm] TokenRequest request)
        {
            // Validate client credentials and username/password here
            if (request.Client_Id == "myclientid" && request.Client_Secret == "mysecret" && request.Username == "user" && request.Password == "pass")
            {
                // Return token (in real life, generate JWT token here)
                return Ok(new TokenResponse
                {
                    Access_Token = "fake-jwt-token-12345"
                });
            }
            return Unauthorized();
        }
    }
}

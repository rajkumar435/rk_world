﻿using Microsoft.AspNetCore.Mvc;

namespace MyApiProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DataController : ControllerBase
    {
        // For demo, static data list
        private static List<MyData> dataList = new()
    {
        new MyData { Id = 1, Name = "Item 1", Value = 100, Processed = false },
        new MyData { Id = 2, Name = "Item 2", Value = 200, Processed = false }
    };

        [HttpGet("unprocessed")]
        public IActionResult GetUnprocessed()
        {
            var unprocessed = dataList.Where(d => !d.Processed).ToList();
            return Ok(unprocessed);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateData(int id, [FromBody] MyData update)
        {
            var item = dataList.FirstOrDefault(d => d.Id == id);
            if (item == null)
                return NotFound();

            item.Value = update.Value;
            item.Processed = update.Processed;

            return Ok(item);
        }
    }

    public class MyData
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Value { get; set; }
        public bool Processed { get; set; }
    }
}

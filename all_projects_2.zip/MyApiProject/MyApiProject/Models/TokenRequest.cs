﻿namespace MyApiProject.Models
{
    public class TokenRequest
    {
        public string Grant_Type { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Client_Id { get; set; }
        public string Client_Secret { get; set; }
    }
}

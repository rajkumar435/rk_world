﻿namespace Asp_Core_WebApp_MVC.Models
{
    public interface IEmployeeData
    {

        public List<Employee> GetEmployees();

    }
}

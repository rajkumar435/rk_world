﻿namespace Asp_Core_WebApp_MVC.Models
{
    public interface ITransient
    {

    }
}

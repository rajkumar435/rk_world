﻿using Microsoft.AspNetCore.Mvc;

namespace Asp_Core_WebApp_MVC.Models
{
    public class EmployeeData : IEmployeeData
    {



        public List<Employee> Employees ;
        public EmployeeData()
        {
            Employees = new List<Employee>()
            {
               new Employee() { Id =1 ,Name ="Raj", Salary =15 },
               new Employee() { Id =2 ,Name ="RK", Salary =16 }
            };
        }

        public List<Employee> GetEmployees( )
        {
            
            

            return Employees;
        }
    }
}

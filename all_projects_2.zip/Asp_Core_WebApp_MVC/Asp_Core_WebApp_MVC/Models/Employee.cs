﻿namespace Asp_Core_WebApp_MVC.Models
{
    public class Employee
    {


        public int Id { get; set; }
        public string Name { get; set; }
        public int Salary { get; set; }

    }
}

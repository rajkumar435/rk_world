﻿using Asp_Core_WebApp_MVC.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Asp_Core_WebApp_MVC.Controllers
{
    //[Route("api/[controller]")]
    //[ApiController]
    public class HomeController : Controller
    {
        public IEmployeeData _employee;
        public HomeController(IEmployeeData employee) 
        {
            this._employee = employee;
        }

        #region with API
        //[HttpGet]
        //public IActionResult Index()
        //{
        //    var employees = _employee.GetEmployees();
        //    return Ok(employees); // returns JSON
        //}
        #endregion



        #region with view
        public ActionResult Index()
        {
            var empdata = _employee.GetEmployees();


            return View(empdata);
        }
        #endregion

    }
}
